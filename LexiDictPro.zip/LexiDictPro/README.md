# LexiDict Pro

A production-ready offline dictionary Android application inspired by GoldenDict.  
Built with **Kotlin + Jetpack Compose + Room FTS5 + ExoPlayer + MLKit OCR + Hilt**.

---

## Features

| Category | Details |
|---|---|
| **Dictionary Formats** | BGL (Babylon), DSL/LSD (ABBYY Lingvo), StarDict (.ifo/.idx/.dict/.dict.dz), dictd (.index+.dict), ZIP archives |
| **Search Modes** | Exact, Prefix, Wildcard, Fuzzy (Levenshtein), Morphological (Porter stemming), Full-Text (FTS5) |
| **Floating Overlay** | System-wide bubble, clipboard monitoring, copy-to-translate |
| **OCR** | CameraX capture → MLKit text recognition → tap-to-lookup |
| **Audio** | Dictionary-embedded audio files via ExoPlayer; TTS fallback |
| **UI** | Material 3, dark/light/dynamic themes, bottom navigation, split-view ready |
| **Performance** | FTS5 indexed search <100ms, WorkManager background indexing, batch DB inserts |

---

## Project Structure

```
LexiDictPro/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/lexidict/pro/
│       │   ├── MainActivity.kt                    # Navigation host + Application class
│       │   ├── audio/
│       │   │   └── AudioEngine.kt                 # ExoPlayer + TTS
│       │   ├── core/
│       │   │   ├── data/local/
│       │   │   │   ├── LexiDictDatabase.kt        # Room DB + FTS5 setup
│       │   │   │   ├── dao/Daos.kt                # All DAO interfaces
│       │   │   │   └── entities/Entities.kt       # Room entity classes
│       │   │   ├── data/repository/
│       │   │   │   └── Repositories.kt            # Search, Dictionary, Favorites repos
│       │   │   ├── di/
│       │   │   │   └── Modules.kt                 # Hilt DI modules
│       │   │   └── domain/model/
│       │   │       └── Models.kt                  # Domain data classes
│       │   ├── feature/
│       │   │   ├── dictionaries/DictionariesScreen.kt
│       │   │   ├── favorites/FavoritesScreen.kt
│       │   │   ├── history/HistoryScreen.kt
│       │   │   ├── import_manager/ImportScreen.kt
│       │   │   ├── ocr/OcrEngine.kt               # MLKit + CameraX OCR screen
│       │   │   ├── search/
│       │   │   │   ├── SearchScreen.kt
│       │   │   │   └── SearchViewModel.kt
│       │   │   └── settings/SettingsScreen.kt
│       │   ├── indexer/
│       │   │   └── SearchEngine.kt                # Multi-mode search engine
│       │   ├── parser/
│       │   │   ├── DictionaryParser.kt            # Interface + factory
│       │   │   ├── bgl/BglParser.kt               # Babylon BGL parser
│       │   │   ├── dictd/DictdParser.kt           # dictd .index/.dict parser
│       │   │   ├── dsl/DslParser.kt               # ABBYY DSL parser
│       │   │   ├── stardict/StarDictParser.kt     # StarDict parser
│       │   │   └── zip/ZipParser.kt               # ZIP wrapper parser
│       │   ├── service/
│       │   │   ├── DictionaryIndexingWorker.kt    # WorkManager background indexer
│       │   │   ├── FloatingOverlayService.kt      # Floating bubble + clipboard
│       │   │   └── LexiDictAccessibilityService.kt# Text selection capture
│       │   └── ui/theme/
│       │       └── Theme.kt                       # Material 3 custom theme
│       └── res/
│           ├── drawable/ic_launcher_foreground.xml
│           ├── values/colors.xml
│           ├── values/strings.xml
│           ├── values/themes.xml
│           ├── values-night/themes.xml
│           └── xml/
│               ├── accessibility_service_config.xml
│               ├── backup_rules.xml
│               ├── data_extraction_rules.xml
│               └── file_paths.xml
├── build.gradle.kts
├── gradle/
│   ├── libs.versions.toml
│   └── wrapper/gradle-wrapper.properties
└── settings.gradle.kts
```

---

## Prerequisites

| Tool | Version |
|---|---|
| Android Studio | Hedgehog (2023.1.1) or newer |
| JDK | 17 (bundled with Android Studio) |
| Android Gradle Plugin | 8.3.2 |
| Gradle | 8.6 |
| Kotlin | 1.9.23 |
| Min SDK | 28 (Android 9) |
| Target SDK | 34 (Android 14) |
| NDK | 25.1+ (for JNI — optional, fallback is pure Kotlin) |

---

## Building

### 1. Clone / open the project

```bash
# Open LexiDictPro/ as an existing project in Android Studio
# OR from command line:
cd LexiDictPro
```

### 2. Sync Gradle

Android Studio will prompt to sync automatically.  
From CLI:

```bash
./gradlew --refresh-dependencies
```

### 3. Debug build

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

### 4. Release build (signed)

```bash
# Generate a keystore if you don't have one:
keytool -genkey -v -keystore lexidict.jks -keyalg RSA -keysize 2048 -validity 10000 -alias lexidict

# Build signed release:
./gradlew assembleRelease \
  -Pandroid.injected.signing.store.file=lexidict.jks \
  -Pandroid.injected.signing.store.password=YOUR_STORE_PASS \
  -Pandroid.injected.signing.key.alias=lexidict \
  -Pandroid.injected.signing.key.password=YOUR_KEY_PASS

# APK: app/build/outputs/apk/release/app-release.apk
```

### 5. Install to connected device

```bash
./gradlew installDebug
```

---

## Required Permissions (declared in AndroidManifest)

| Permission | Purpose |
|---|---|
| `SYSTEM_ALERT_WINDOW` | Floating overlay bubble |
| `BIND_ACCESSIBILITY_SERVICE` | Copy-to-translate text capture |
| `FOREGROUND_SERVICE` | Background dictionary indexing |
| `CAMERA` | OCR camera capture |
| `READ_MEDIA_IMAGES` | OCR from image files (API 33+) |
| `READ_EXTERNAL_STORAGE` | Dictionary import (API ≤32) |
| `MANAGE_EXTERNAL_STORAGE` | Optional: for large dictionary folders |

All dangerous permissions are requested at runtime with proper rationale dialogs.

---

## First-time setup in the app

1. **Import a dictionary**: Dictionaries → FAB (+) → select BGL/DSL/StarDict/dictd/ZIP file
2. **Wait for indexing**: progress shown in Import screen (background WorkManager job)
3. **Search**: tap Search tab → type any word

---

## Overlay / Floating Bubble

1. Settings → grant **Overlay Permission** (opens system settings)
2. Settings → enable **Floating Bubble**
3. Settings → enable **Clipboard Monitoring** for auto-popup on copy

For **Copy-to-Translate** without clipboard:
- Settings → **Accessibility Service** → enable LexiDict Pro

---

## Architecture Notes

### Clean Architecture layers

```
UI (Compose) → ViewModel → Repository → DAO / Parser → Room / File
```

### Search pipeline

```
User input
  → SearchViewModel (debounce 150ms)
  → SearchRepository
  → SearchEngine.search(query, mode)
      ├── EXACT   : WordIndexDao.searchExact()
      ├── PREFIX  : WordIndexDao.searchPrefix()
      ├── FULLTEXT: WordIndexDao.searchFts() (FTS5 MATCH)
      ├── FUZZY   : Levenshtein DP in-memory filter
      ├── WILDCARD: SQL GLOB
      └── MORPHOLOGICAL: Porter stemmer → PREFIX search
  → scored + ranked results
  → groupResultsByWord() [multi-dictionary grouping]
  → SearchUiState
```

### FTS5 setup

Room does not natively create FTS5 virtual tables, so the database Callback creates them with raw SQL:

```sql
CREATE VIRTUAL TABLE IF NOT EXISTS word_index_fts
USING fts5(word, definition, content='word_index', content_rowid='id', tokenize='unicode61');
```

Three triggers keep the FTS index in sync with the main `word_index` table on insert, update, delete.

### Background indexing

`DictionaryIndexingWorker` (HiltWorker + CoroutineWorker):
- Runs as a foreground service (dataSync type) with a persistent notification
- Streams parsed words from the parser via `Flow<ParseProgress>` 
- Batch-inserts into Room (500 words per transaction)
- Reports progress via WorkManager `setProgress()`

---

## Adding a new dictionary format

1. Create `parser/myformat/MyFormatParser.kt` implementing `DictionaryParser`
2. Add it to the `parsers` list in `DictionaryParserFactory`
3. Add format detection in `DictionaryParserFactory.detectFormat()`
4. Add the file extension to `DictionaryFormat` enum

---

## Open-source dependencies

| Library | Purpose | License |
|---|---|---|
| Jetpack Compose BOM 2024.05 | UI framework | Apache 2.0 |
| Room 2.6.1 | SQLite ORM + FTS5 | Apache 2.0 |
| Hilt 2.51.1 | Dependency injection | Apache 2.0 |
| Media3 (ExoPlayer) 1.3.1 | Audio playback | Apache 2.0 |
| CameraX 1.3.2 | Camera capture for OCR | Apache 2.0 |
| MLKit Text Recognition 16.0.0 | OCR | Apache 2.0 |
| WorkManager 2.9.0 | Background tasks | Apache 2.0 |
| Coil 2.6.0 | Image loading | Apache 2.0 |
| Jsoup 1.17.2 | HTML parsing/sanitization | MIT |
| Okio 3.9.0 | Efficient I/O | Apache 2.0 |
| Navigation Compose 2.7.7 | In-app navigation | Apache 2.0 |
| Accompanist 0.34.0 | Compose utilities | Apache 2.0 |

---

## Known limitations / future work

- **LSD format** (ABBYY Lingvo compiled): requires reverse-engineered binary format; JNI stub provided but full implementation needs the LSD specification.
- **PDF dictionaries**: architecture placeholder only; full PDF parsing requires a PDF library (e.g. PdfRenderer for images, or iText for text extraction).
- **Cloud sync**: architecture uses placeholder; implement with WorkManager + your backend.
- **AI features**: optional architecture stub; connect to Anthropic/OpenAI API in `SearchEngine` for AI-ranked results.
- **Tablet split-view**: single-pane at present; add `TwoPaneLayout` from Accompanist for tablets.

---

## License

```
Copyright 2024 LexiDict Pro

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0
```
