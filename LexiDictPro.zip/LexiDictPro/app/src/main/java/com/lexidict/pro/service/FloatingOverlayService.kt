package com.lexidict.pro.service

import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.unit.dp
import androidx.lifecycle.*
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import com.lexidict.pro.core.domain.model.SearchMode
import com.lexidict.pro.core.domain.model.SearchQuery

/**
 * System-wide floating overlay service.
 *
 * Features:
 * - Monitors clipboard for text changes
 * - Shows floating bubble when text is copied
 * - Displays popup dictionary definition via ComposeView
 * - Draggable, resizable floating window
 * - Requires SYSTEM_ALERT_WINDOW permission
 */
class FloatingOverlayService : Service(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    // Lifecycle scaffolding for ComposeView in a Service
    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    private val vmStore = ViewModelStore()
    override val viewModelStore: ViewModelStore get() = vmStore

    private val savedStateController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry get() = savedStateController.savedStateRegistry

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var bubbleView: View? = null

    private lateinit var clipboardManager: ClipboardManager
    private var clipboardListener: ClipboardManager.OnPrimaryClipChangedListener? = null

    companion object {
        const val ACTION_SHOW_WORD = "com.lexidict.pro.SHOW_WORD"
        const val EXTRA_WORD = "word"

        fun showWord(context: Context, word: String) {
            val intent = Intent(context, FloatingOverlayService::class.java).apply {
                action = ACTION_SHOW_WORD
                putExtra(EXTRA_WORD, word)
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        savedStateController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        clipboardManager = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager

        // Monitor clipboard
        clipboardListener = ClipboardManager.OnPrimaryClipChangedListener {
            val text = clipboardManager.primaryClip
                ?.getItemAt(0)?.text?.toString()?.trim() ?: return@OnPrimaryClipChangedListener
            if (text.isNotBlank() && text.length < 100 && !text.contains("\n")) {
                showBubble(text)
            }
        }
        clipboardManager.addPrimaryClipChangedListener(clipboardListener!!)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_SHOW_WORD) {
            val word = intent.getStringExtra(EXTRA_WORD) ?: return START_STICKY
            showDefinitionOverlay(word)
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        vmStore.clear()
        clipboardListener?.let { clipboardManager.removePrimaryClipChangedListener(it) }
        removeOverlay()
        removeBubble()
        super.onDestroy()
    }

    // ─────────────────────────────────────────────────────────────
    //  FLOATING BUBBLE
    // ─────────────────────────────────────────────────────────────

    private fun showBubble(word: String) {
        removeBubble()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 200
        }

        val composeView = ComposeView(this).apply {
            setViewCompositionStrategy(
                androidx.compose.ui.platform.ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed
            )
            setContent {
                MaterialTheme {
                    FloatingBubble(
                        word = word,
                        onTap = { showDefinitionOverlay(word) },
                        onDismiss = { removeBubble() }
                    )
                }
            }
        }

        // Make ComposeView lifecycle-aware
        composeView.setViewTreeLifecycleOwner(this)
        composeView.setViewTreeViewModelStoreOwner(this)
        composeView.setViewTreeSavedStateRegistryOwner(this)

        // Touch listener for dragging bubble
        var initX = 0; var initY = 0; var initTouchX = 0f; var initTouchY = 0f
        composeView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initX = params.x; initY = params.y
                    initTouchX = event.rawX; initTouchY = event.rawY
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initX + (event.rawX - initTouchX).toInt()
                    params.y = initY + (event.rawY - initTouchY).toInt()
                    windowManager.updateViewLayout(composeView, params)
                    true
                }
                else -> false
            }
        }

        bubbleView = composeView
        windowManager.addView(composeView, params)
    }

    private fun removeBubble() {
        bubbleView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
            bubbleView = null
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  DEFINITION OVERLAY
    // ─────────────────────────────────────────────────────────────

    private fun showDefinitionOverlay(word: String) {
        removeOverlay()

        val params = WindowManager.LayoutParams(
            700, // dp-ish width
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        val composeView = ComposeView(this).apply {
            setViewCompositionStrategy(
                androidx.compose.ui.platform.ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed
            )
            setContent {
                MaterialTheme {
                    PopupDefinitionCard(
                        word = word,
                        onClose = { removeOverlay() }
                    )
                }
            }
        }

        composeView.setViewTreeLifecycleOwner(this)
        composeView.setViewTreeViewModelStoreOwner(this)
        composeView.setViewTreeSavedStateRegistryOwner(this)

        overlayView = composeView
        windowManager.addView(composeView, params)
    }

    private fun removeOverlay() {
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
            overlayView = null
        }
    }
}

// ─────────────────────────────────────────────────────────────
//  COMPOSE UI FOR OVERLAY
// ─────────────────────────────────────────────────────────────

@Composable
private fun FloatingBubble(
    word: String,
    onTap: () -> Unit,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier.padding(8.dp),
        elevation = CardDefaults.cardElevation(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "📖",
                style = MaterialTheme.typography.bodyMedium
            )
            TextButton(onClick = onTap) {
                Text(
                    text = word.take(30),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }
            IconButton(onClick = onDismiss, modifier = Modifier.size(20.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Dismiss",
                    modifier = Modifier.size(14.dp))
            }
        }
    }
}

@Composable
private fun PopupDefinitionCard(
    word: String,
    onClose: () -> Unit
) {
    // In full implementation: inject SearchRepository and look up definition
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        elevation = CardDefaults.cardElevation(16.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .heightIn(max = 400.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = word,
                    style = MaterialTheme.typography.headlineSmall
                )
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, "Close")
                }
            }
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            Text(
                text = "Definition loading...",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
