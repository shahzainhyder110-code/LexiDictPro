package com.lexidict.pro.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.net.Uri
import androidx.core.app.NotificationCompat
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.lexidict.pro.core.data.local.dao.DictionaryDao
import com.lexidict.pro.core.data.local.dao.ImportJobDao
import com.lexidict.pro.core.data.local.dao.WordIndexDao
import com.lexidict.pro.core.data.local.entities.DictionaryEntity
import com.lexidict.pro.core.domain.model.DictionaryFormat
import com.lexidict.pro.core.domain.model.ImportState
import com.lexidict.pro.parser.DictionaryParserFactory
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectIndexed
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/**
 * Background WorkManager Worker for dictionary indexing.
 * Runs as a foreground service to survive process death.
 *
 * Input data keys:
 * - [KEY_DICTIONARY_PATH]: Absolute path to dictionary file
 * - [KEY_DICTIONARY_ID]: Room DB id of the DictionaryEntity
 * - [KEY_JOB_ID]: Import job UUID for progress tracking
 */
@HiltWorker
class DictionaryIndexingWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted workerParams: WorkerParameters,
    private val parserFactory: DictionaryParserFactory,
    private val dictionaryDao: DictionaryDao,
    private val wordIndexDao: WordIndexDao,
    private val importJobDao: ImportJobDao
) : CoroutineWorker(context, workerParams) {

    companion object {
        const val KEY_DICTIONARY_PATH = "dictionary_path"
        const val KEY_DICTIONARY_ID   = "dictionary_id"
        const val KEY_JOB_ID          = "job_id"
        const val NOTIFICATION_ID     = 1001
        const val CHANNEL_ID          = "indexing_channel"

        fun buildRequest(
            filePath: String,
            dictionaryId: Long,
            jobId: String
        ): OneTimeWorkRequest = OneTimeWorkRequestBuilder<DictionaryIndexingWorker>()
            .setInputData(
                workDataOf(
                    KEY_DICTIONARY_PATH to filePath,
                    KEY_DICTIONARY_ID   to dictionaryId,
                    KEY_JOB_ID          to jobId
                )
            )
            .setConstraints(
                Constraints.Builder()
                    .setRequiresStorageNotLow(true)
                    .build()
            )
            .addTag("indexing_$dictionaryId")
            .build()
    }

    override suspend fun getForegroundInfo(): ForegroundInfo {
        createNotificationChannel()
        return ForegroundInfo(
            NOTIFICATION_ID,
            buildNotification("Indexing dictionary...", 0),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val filePath     = inputData.getString(KEY_DICTIONARY_PATH) ?: return@withContext Result.failure()
        val dictionaryId = inputData.getLong(KEY_DICTIONARY_ID, -1L)
        val jobId        = inputData.getString(KEY_JOB_ID) ?: UUID.randomUUID().toString()

        if (dictionaryId == -1L) return@withContext Result.failure()

        val file = File(filePath)
        if (!file.exists()) return@withContext Result.failure()

        try {
            // Mark as indexing
            importJobDao.updateProgress(jobId, ImportState.INDEXING.name, 0)

            val parser = parserFactory.getParser(file)
                ?: return@withContext Result.failure()

            // Estimate word count for progress
            val estimatedCount = parser.estimateWordCount(file).coerceAtLeast(1)
            var processedWords = 0L

            // Clear existing index for this dictionary (re-index scenario)
            wordIndexDao.deleteWordsForDictionary(dictionaryId)

            // Stream and insert word batches
            parser.parseWords(file, dictionaryId).collectIndexed { index, batch ->
                if (isStopped) return@collectIndexed // Cancellation check

                // Batch insert
                wordIndexDao.insertWords(batch)
                processedWords += batch.size

                // Update progress
                val percent = ((processedWords * 100) / estimatedCount).toInt().coerceIn(0, 99)
                importJobDao.updateProgress(jobId, ImportState.INDEXING.name, percent)

                // Update notification every 10 batches
                if (index % 10 == 0) {
                    setForeground(ForegroundInfo(
                        NOTIFICATION_ID,
                        buildNotification("Indexing: $processedWords words...", percent),
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                    ))
                }
            }

            // Final word count from DB (accurate)
            val finalCount = wordIndexDao.getWordCount(dictionaryId)

            // Mark dictionary as indexed
            dictionaryDao.setIndexed(dictionaryId, true, finalCount)

            // Mark job complete
            importJobDao.updateProgress(jobId, ImportState.COMPLETED.name, 100)

            Result.success(workDataOf("word_count" to finalCount))

        } catch (e: Exception) {
            importJobDao.setFailed(jobId, ImportState.FAILED.name, e.message ?: "Unknown error")
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Dictionary Indexing",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Background dictionary indexing progress"
        }
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(channel)
    }

    private fun buildNotification(message: String, progress: Int): Notification =
        NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_sort_by_size)
            .setContentTitle("LexiDict Pro")
            .setContentText(message)
            .setProgress(100, progress, progress == 0)
            .setOngoing(true)
            .setSilent(true)
            .build()
}

// ═══════════════════════════════════════════════════════════════
//  IMPORT MANAGER — orchestrates the full import pipeline
// ═══════════════════════════════════════════════════════════════

class ImportManager(
    private val context: Context,
    private val parserFactory: DictionaryParserFactory,
    private val dictionaryDao: DictionaryDao,
    private val importJobDao: ImportJobDao
) {
    /**
     * Import a dictionary from a URI.
     * Flow:
     * 1. Copy to internal cache (for SAF URIs)
     * 2. Detect format
     * 3. Extract metadata → insert DictionaryEntity
     * 4. Enqueue WorkManager indexing job
     * 5. Emit progress states
     */
    suspend fun importDictionary(uri: Uri): kotlinx.coroutines.flow.Flow<ImportState> =
        kotlinx.coroutines.flow.flow {
            emit(ImportState.DETECTING_FORMAT)

            // Resolve to a File (copy if needed from SAF)
            val file = resolveToFile(uri) ?: run {
                emit(ImportState.FAILED)
                return@flow
            }

            val parser = parserFactory.getParser(file) ?: run {
                emit(ImportState.FAILED)
                return@flow
            }

            emit(ImportState.EXTRACTING_METADATA)
            val metadata = parser.extractMetadata(file)

            // Insert into DB to get ID
            val dictId = dictionaryDao.insertDictionary(
                DictionaryEntity(
                    name = metadata.name,
                    author = metadata.author,
                    description = metadata.description,
                    sourceLanguage = metadata.sourceLanguage,
                    targetLanguage = metadata.targetLanguage,
                    wordCount = metadata.wordCount,
                    filePath = file.absolutePath,
                    format = metadata.format.name,
                    sizeBytes = metadata.sizeBytes,
                    isEnabled = true,
                    isIndexed = false
                )
            )

            emit(ImportState.INDEXING)

            // Enqueue background indexing
            val jobId = UUID.randomUUID().toString()
            val workRequest = DictionaryIndexingWorker.buildRequest(
                file.absolutePath, dictId, jobId
            )
            WorkManager.getInstance(context).enqueue(workRequest)

            emit(ImportState.QUEUED)
        }

    private fun resolveToFile(uri: Uri): File? {
        return try {
            when (uri.scheme) {
                "file" -> File(uri.path ?: return null)
                "content" -> {
                    // SAF URI — copy to cache
                    val fileName = getFileNameFromUri(uri) ?: "dictionary_${System.currentTimeMillis()}"
                    val cacheFile = File(context.cacheDir, "imports/$fileName")
                    cacheFile.parentFile?.mkdirs()
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        cacheFile.outputStream().use { output ->
                            input.copyTo(output)
                        }
                    }
                    cacheFile
                }
                else -> null
            }
        } catch (e: Exception) { null }
    }

    private fun getFileNameFromUri(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) result = cursor.getString(idx)
                }
            }
        }
        return result ?: uri.lastPathSegment
    }
}
