package com.lexidict.pro.core.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.lexidict.pro.core.data.local.dao.*
import com.lexidict.pro.core.data.local.entities.*

// ═══════════════════════════════════════════════════════════════
//  ROOM DATABASE
// ═══════════════════════════════════════════════════════════════

@Database(
    entities = [
        DictionaryEntity::class,
        WordIndexFtsEntity::class,
        SearchHistoryEntity::class,
        FavoriteEntity::class,
        AudioCacheEntity::class,
        ImportJobEntity::class
    ],
    version = 1,
    exportSchema = true
)
@TypeConverters(Converters::class)
abstract class LexiDictDatabase : RoomDatabase() {

    abstract fun dictionaryDao(): DictionaryDao
    abstract fun wordIndexDao(): WordIndexDao
    abstract fun searchHistoryDao(): SearchHistoryDao
    abstract fun favoritesDao(): FavoritesDao
    abstract fun audioCacheDao(): AudioCacheDao
    abstract fun importJobDao(): ImportJobDao

    companion object {
        const val DATABASE_NAME = "lexidict_pro.db"

        /**
         * Callback to create FTS5 virtual table and triggers.
         * Room doesn't natively support FTS5, so we create it manually.
         */
        val CALLBACK = object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)

                // Create FTS5 virtual table for ultra-fast search
                db.execSQL("""
                    CREATE VIRTUAL TABLE IF NOT EXISTS word_index_fts_search
                    USING fts5(
                        word,
                        definition,
                        content='word_index_fts',
                        content_rowid='rowid',
                        tokenize='unicode61 remove_diacritics 2'
                    )
                """.trimIndent())

                // Trigger: keep FTS5 in sync with word_index_fts inserts
                db.execSQL("""
                    CREATE TRIGGER IF NOT EXISTS word_fts_insert
                    AFTER INSERT ON word_index_fts BEGIN
                        INSERT INTO word_index_fts_search(rowid, word, definition)
                        VALUES (new.rowid, new.word, new.definition);
                    END
                """.trimIndent())

                // Trigger: keep FTS5 in sync with deletes
                db.execSQL("""
                    CREATE TRIGGER IF NOT EXISTS word_fts_delete
                    BEFORE DELETE ON word_index_fts BEGIN
                        INSERT INTO word_index_fts_search(word_index_fts_search, rowid, word, definition)
                        VALUES ('delete', old.rowid, old.word, old.definition);
                    END
                """.trimIndent())

                // Trigger: keep FTS5 in sync with updates
                db.execSQL("""
                    CREATE TRIGGER IF NOT EXISTS word_fts_update
                    AFTER UPDATE ON word_index_fts BEGIN
                        INSERT INTO word_index_fts_search(word_index_fts_search, rowid, word, definition)
                        VALUES ('delete', old.rowid, old.word, old.definition);
                        INSERT INTO word_index_fts_search(rowid, word, definition)
                        VALUES (new.rowid, new.word, new.definition);
                    END
                """.trimIndent())

                // Optimize: WAL mode for concurrent reads during indexing
                db.execSQL("PRAGMA journal_mode=WAL")
                db.execSQL("PRAGMA synchronous=NORMAL")
                db.execSQL("PRAGMA cache_size=-32000")  // 32MB cache
                db.execSQL("PRAGMA temp_store=MEMORY")
            }

            override fun onOpen(db: SupportSQLiteDatabase) {
                super.onOpen(db)
                // Re-apply WAL on open (persists but good to be explicit)
                db.execSQL("PRAGMA journal_mode=WAL")
                db.execSQL("PRAGMA cache_size=-32000")
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════
//  TYPE CONVERTERS
// ═══════════════════════════════════════════════════════════════

class Converters {
    @androidx.room.TypeConverter
    fun fromStringList(value: List<String>?): String =
        value?.joinToString(",") ?: ""

    @androidx.room.TypeConverter
    fun toStringList(value: String): List<String> =
        if (value.isEmpty()) emptyList() else value.split(",")
}
