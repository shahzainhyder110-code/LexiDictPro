package com.lexidict.pro.core.data.local.dao

import androidx.room.*
import com.lexidict.pro.core.data.local.entities.*
import kotlinx.coroutines.flow.Flow

// ═══════════════════════════════════════════════════════════════
//  DICTIONARY DAO
// ═══════════════════════════════════════════════════════════════

@Dao
interface DictionaryDao {

    @Query("SELECT * FROM dictionaries ORDER BY priority DESC, name ASC")
    fun getAllDictionaries(): Flow<List<DictionaryEntity>>

    @Query("SELECT * FROM dictionaries WHERE is_enabled = 1 ORDER BY priority DESC")
    fun getEnabledDictionaries(): Flow<List<DictionaryEntity>>

    @Query("SELECT * FROM dictionaries WHERE id = :id")
    suspend fun getDictionaryById(id: Long): DictionaryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDictionary(dictionary: DictionaryEntity): Long

    @Update
    suspend fun updateDictionary(dictionary: DictionaryEntity)

    @Delete
    suspend fun deleteDictionary(dictionary: DictionaryEntity)

    @Query("UPDATE dictionaries SET is_enabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Long, enabled: Boolean)

    @Query("UPDATE dictionaries SET is_indexed = :indexed, word_count = :wordCount WHERE id = :id")
    suspend fun setIndexed(id: Long, indexed: Boolean, wordCount: Long)

    @Query("UPDATE dictionaries SET priority = :priority WHERE id = :id")
    suspend fun updatePriority(id: Long, priority: Int)

    @Query("SELECT COUNT(*) FROM dictionaries")
    suspend fun getDictionaryCount(): Int
}

// ═══════════════════════════════════════════════════════════════
//  WORD INDEX DAO — FTS5 search
// ═══════════════════════════════════════════════════════════════

@Dao
interface WordIndexDao {

    /**
     * Prefix search — ultra fast via FTS5 MATCH with * suffix.
     * Used for autocomplete suggestions.
     */
    @Query("""
        SELECT wi.*, d.name as dict_name
        FROM word_index_fts wi
        JOIN dictionaries d ON wi.dictionary_id = d.id
        WHERE wi.word_lower LIKE :prefix || '%'
        AND d.is_enabled = 1
        ORDER BY wi.word_lower ASC
        LIMIT :limit
    """)
    suspend fun searchByPrefix(prefix: String, limit: Int = 20): List<WordWithDictName>

    /**
     * Exact word match across all enabled dictionaries.
     */
    @Query("""
        SELECT wi.*, d.name as dict_name
        FROM word_index_fts wi
        JOIN dictionaries d ON wi.dictionary_id = d.id
        WHERE wi.word_lower = :word
        AND d.is_enabled = 1
        ORDER BY d.priority DESC
    """)
    suspend fun searchExact(word: String): List<WordWithDictName>

    /**
     * Full-text search in definitions using FTS5 MATCH.
     * Requires FTS5 virtual table (created in DB callback).
     */
    @RawQuery
    suspend fun searchFullText(query: androidx.sqlite.db.SupportSQLiteQuery): List<WordWithDictName>

    /**
     * Fuzzy search: words within Levenshtein distance 1-2.
     * Falls back to LIKE % pattern for approximate matching.
     */
    @Query("""
        SELECT wi.*, d.name as dict_name
        FROM word_index_fts wi
        JOIN dictionaries d ON wi.dictionary_id = d.id
        WHERE wi.word_lower LIKE '%' || :fragment || '%'
        AND d.is_enabled = 1
        ORDER BY LENGTH(wi.word) ASC
        LIMIT :limit
    """)
    suspend fun searchFuzzy(fragment: String, limit: Int = 30): List<WordWithDictName>

    /**
     * Wildcard search: supports * and ? via SQL GLOB.
     */
    @Query("""
        SELECT wi.*, d.name as dict_name
        FROM word_index_fts wi
        JOIN dictionaries d ON wi.dictionary_id = d.id
        WHERE wi.word_lower GLOB :pattern
        AND d.is_enabled = 1
        ORDER BY wi.word_lower ASC
        LIMIT :limit
    """)
    suspend fun searchWildcard(pattern: String, limit: Int = 50): List<WordWithDictName>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWords(words: List<WordIndexFtsEntity>)

    @Query("DELETE FROM word_index_fts WHERE dictionary_id = :dictionaryId")
    suspend fun deleteWordsForDictionary(dictionaryId: Long)

    @Query("SELECT COUNT(*) FROM word_index_fts WHERE dictionary_id = :dictionaryId")
    suspend fun getWordCount(dictionaryId: Long): Long

    /**
     * Alphabetical word list for dictionary browsing.
     */
    @Query("""
        SELECT * FROM word_index_fts
        WHERE dictionary_id = :dictionaryId
        ORDER BY sort_key ASC
        LIMIT :limit OFFSET :offset
    """)
    suspend fun browseWords(dictionaryId: Long, limit: Int, offset: Int): List<WordIndexFtsEntity>
}

// ═══════════════════════════════════════════════════════════════
//  POJO for JOIN result
// ═══════════════════════════════════════════════════════════════

data class WordWithDictName(
    val rowId: Long,
    val dictionaryId: Long,
    val word: String,
    val wordLower: String,
    val definition: String,
    val pronunciation: String,
    val audioPath: String,
    val sortKey: String,
    val dict_name: String
)

// ═══════════════════════════════════════════════════════════════
//  SEARCH HISTORY DAO
// ═══════════════════════════════════════════════════════════════

@Dao
interface SearchHistoryDao {

    @Query("SELECT * FROM search_history ORDER BY searched_at DESC LIMIT :limit")
    fun getRecentHistory(limit: Int = 50): Flow<List<SearchHistoryEntity>>

    @Query("SELECT * FROM search_history WHERE word LIKE :prefix || '%' ORDER BY searched_at DESC LIMIT 10")
    suspend fun getSuggestionsForPrefix(prefix: String): List<SearchHistoryEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: SearchHistoryEntity)

    @Query("DELETE FROM search_history WHERE word = :word")
    suspend fun deleteByWord(word: String)

    @Query("DELETE FROM search_history")
    suspend fun clearAll()

    @Query("DELETE FROM search_history WHERE id IN (SELECT id FROM search_history ORDER BY searched_at ASC LIMIT :count)")
    suspend fun deleteOldest(count: Int)

    @Query("SELECT COUNT(*) FROM search_history")
    suspend fun getCount(): Int
}

// ═══════════════════════════════════════════════════════════════
//  FAVORITES DAO
// ═══════════════════════════════════════════════════════════════

@Dao
interface FavoritesDao {

    @Query("SELECT * FROM favorites ORDER BY saved_at DESC")
    fun getAllFavorites(): Flow<List<FavoriteEntity>>

    @Query("SELECT * FROM favorites WHERE word = :word LIMIT 1")
    suspend fun getFavoriteByWord(word: String): FavoriteEntity?

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE word = :word)")
    fun isFavorite(word: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(favorite: FavoriteEntity)

    @Delete
    suspend fun delete(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE word = :word")
    suspend fun deleteByWord(word: String)

    @Query("SELECT COUNT(*) FROM favorites")
    suspend fun getCount(): Int
}

// ═══════════════════════════════════════════════════════════════
//  AUDIO CACHE DAO
// ═══════════════════════════════════════════════════════════════

@Dao
interface AudioCacheDao {

    @Query("SELECT * FROM audio_cache WHERE word = :word AND locale = :locale LIMIT 1")
    suspend fun getCachedAudio(word: String, locale: String): AudioCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(audio: AudioCacheEntity)

    @Query("DELETE FROM audio_cache WHERE cached_at < :before")
    suspend fun evictOlderThan(before: Long)

    @Query("SELECT COUNT(*) FROM audio_cache")
    suspend fun getCount(): Int
}

// ═══════════════════════════════════════════════════════════════
//  IMPORT JOB DAO
// ═══════════════════════════════════════════════════════════════

@Dao
interface ImportJobDao {

    @Query("SELECT * FROM import_jobs ORDER BY created_at DESC")
    fun getAllJobs(): Flow<List<ImportJobEntity>>

    @Query("SELECT * FROM import_jobs WHERE id = :id")
    suspend fun getJob(id: String): ImportJobEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(job: ImportJobEntity)

    @Query("UPDATE import_jobs SET state = :state, progress = :progress WHERE id = :id")
    suspend fun updateProgress(id: String, state: String, progress: Int)

    @Query("UPDATE import_jobs SET state = :state, error_message = :error WHERE id = :id")
    suspend fun setFailed(id: String, state: String, error: String)

    @Query("DELETE FROM import_jobs WHERE id = :id")
    suspend fun delete(id: String)
}
