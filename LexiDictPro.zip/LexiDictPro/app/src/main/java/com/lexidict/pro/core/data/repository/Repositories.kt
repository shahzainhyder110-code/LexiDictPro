package com.lexidict.pro.core.data.repository

import com.lexidict.pro.core.data.local.dao.*
import com.lexidict.pro.core.data.local.entities.*
import com.lexidict.pro.core.domain.model.*
import com.lexidict.pro.indexer.SearchEngine
import com.lexidict.pro.parser.DictionaryParserFactory
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

// ═══════════════════════════════════════════════════════════════
//  SEARCH REPOSITORY
// ═══════════════════════════════════════════════════════════════

interface SearchRepository {
    suspend fun search(query: SearchQuery): List<WordEntry>
    suspend fun searchExact(word: String): List<WordEntry>
    suspend fun getSuggestions(prefix: String): List<String>
    fun getSearchHistory(): Flow<List<SearchHistoryEntry>>
    suspend fun addToHistory(word: String)
    suspend fun clearHistory()
}

class SearchRepositoryImpl @Inject constructor(
    private val wordIndexDao: WordIndexDao,
    private val searchHistoryDao: SearchHistoryDao,
    private val dictionaryDao: DictionaryDao,
    private val searchEngine: SearchEngine
) : SearchRepository {

    override suspend fun search(query: SearchQuery): List<WordEntry> {
        val rawResults = searchEngine.search(wordIndexDao, query)
        return groupResultsByWord(rawResults)
    }

    override suspend fun searchExact(word: String): List<WordEntry> {
        val rawResults = wordIndexDao.searchExact(word.lowercase()).map { row ->
            SearchResult(
                word = row.word,
                definition = row.definition,
                definitionHtml = row.definition,
                dictionaryId = row.dictionaryId,
                dictionaryName = row.dict_name,
                pronunciation = row.pronunciation.ifEmpty { null },
                audioPath = row.audioPath.ifEmpty { null }
            )
        }
        return groupResultsByWord(rawResults)
    }

    override suspend fun getSuggestions(prefix: String): List<String> =
        searchEngine.getSuggestions(wordIndexDao, prefix)

    override fun getSearchHistory(): Flow<List<SearchHistoryEntry>> =
        searchHistoryDao.getRecentHistory().map { entities ->
            entities.map { SearchHistoryEntry(it.id, it.word, it.searchedAt, it.dictionaryId) }
        }

    override suspend fun addToHistory(word: String) {
        // Check history size limit
        val count = searchHistoryDao.getCount()
        if (count >= 500) searchHistoryDao.deleteOldest(50)
        searchHistoryDao.insert(SearchHistoryEntity(word = word))
    }

    override suspend fun clearHistory() = searchHistoryDao.clearAll()

    private fun groupResultsByWord(results: List<SearchResult>): List<WordEntry> {
        return results.groupBy { it.word }
            .map { (word, wordResults) ->
                WordEntry(
                    word = word,
                    results = wordResults.sortedByDescending { it.rank }
                )
            }
    }
}

// ═══════════════════════════════════════════════════════════════
//  DICTIONARY REPOSITORY
// ═══════════════════════════════════════════════════════════════

interface DictionaryRepository {
    fun getAllDictionaries(): Flow<List<Dictionary>>
    fun getEnabledDictionaries(): Flow<List<Dictionary>>
    suspend fun getDictionaryById(id: Long): Dictionary?
    suspend fun insertDictionary(dictionary: Dictionary): Long
    suspend fun deleteDictionary(id: Long)
    suspend fun setEnabled(id: Long, enabled: Boolean)
    suspend fun updatePriority(id: Long, priority: Int)
}

class DictionaryRepositoryImpl @Inject constructor(
    private val dictionaryDao: DictionaryDao,
    private val wordIndexDao: WordIndexDao,
    private val importJobDao: ImportJobDao,
    private val parserFactory: DictionaryParserFactory
) : DictionaryRepository {

    override fun getAllDictionaries(): Flow<List<Dictionary>> =
        dictionaryDao.getAllDictionaries().map { it.map { e -> e.toDomain() } }

    override fun getEnabledDictionaries(): Flow<List<Dictionary>> =
        dictionaryDao.getEnabledDictionaries().map { it.map { e -> e.toDomain() } }

    override suspend fun getDictionaryById(id: Long): Dictionary? =
        dictionaryDao.getDictionaryById(id)?.toDomain()

    override suspend fun insertDictionary(dictionary: Dictionary): Long =
        dictionaryDao.insertDictionary(dictionary.toEntity())

    override suspend fun deleteDictionary(id: Long) {
        val entity = dictionaryDao.getDictionaryById(id) ?: return
        wordIndexDao.deleteWordsForDictionary(id)
        dictionaryDao.deleteDictionary(entity)
    }

    override suspend fun setEnabled(id: Long, enabled: Boolean) =
        dictionaryDao.setEnabled(id, enabled)

    override suspend fun updatePriority(id: Long, priority: Int) =
        dictionaryDao.updatePriority(id, priority)
}

// ═══════════════════════════════════════════════════════════════
//  FAVORITES REPOSITORY
// ═══════════════════════════════════════════════════════════════

interface FavoritesRepository {
    fun getAllFavorites(): Flow<List<FavoriteEntry>>
    fun isFavorite(word: String): Flow<Boolean>
    suspend fun addToFavorites(entry: FavoriteEntry)
    suspend fun removeFromFavorites(word: String)
}

class FavoritesRepositoryImpl @Inject constructor(
    private val favoritesDao: FavoritesDao
) : FavoritesRepository {

    override fun getAllFavorites(): Flow<List<FavoriteEntry>> =
        favoritesDao.getAllFavorites().map { it.map { e ->
            FavoriteEntry(e.id, e.word, e.definition, e.dictionaryId, e.dictionaryName, e.savedAt, e.note)
        }}

    override fun isFavorite(word: String): Flow<Boolean> =
        favoritesDao.isFavorite(word)

    override suspend fun addToFavorites(entry: FavoriteEntry) =
        favoritesDao.insert(FavoriteEntity(
            word = entry.word,
            definition = entry.definition,
            dictionaryId = entry.dictionaryId,
            dictionaryName = entry.dictionaryName,
            note = entry.note
        ))

    override suspend fun removeFromFavorites(word: String) =
        favoritesDao.deleteByWord(word)
}

// ═══════════════════════════════════════════════════════════════
//  MAPPERS
// ═══════════════════════════════════════════════════════════════

private fun DictionaryEntity.toDomain() = Dictionary(
    id = id, name = name, author = author, description = description,
    sourceLanguage = sourceLanguage, targetLanguage = targetLanguage,
    wordCount = wordCount, filePath = filePath, indexPath = indexPath,
    format = DictionaryFormat.valueOf(format.ifEmpty { "UNKNOWN" }),
    sizeBytes = sizeBytes, isEnabled = isEnabled, isIndexed = isIndexed,
    importedAt = importedAt, priority = priority,
    coverImagePath = coverImagePath, hasPronunciation = hasPronunciation,
    hasImages = hasImages
)

private fun Dictionary.toEntity() = DictionaryEntity(
    id = id, name = name, author = author, description = description,
    sourceLanguage = sourceLanguage, targetLanguage = targetLanguage,
    wordCount = wordCount, filePath = filePath, indexPath = indexPath,
    format = format.name, sizeBytes = sizeBytes, isEnabled = isEnabled,
    isIndexed = isIndexed, importedAt = importedAt, priority = priority,
    coverImagePath = coverImagePath, hasPronunciation = hasPronunciation,
    hasImages = hasImages
)
