package com.lexidict.pro.core.di

import android.content.Context
import androidx.room.Room
import com.lexidict.pro.core.data.local.LexiDictDatabase
import com.lexidict.pro.core.data.local.dao.*
import com.lexidict.pro.core.data.repository.*
import com.lexidict.pro.parser.DictionaryParserFactory
import com.lexidict.pro.audio.AudioEngine
import com.lexidict.pro.indexer.SearchEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

// ═══════════════════════════════════════════════════════════════
//  DATABASE MODULE
// ═══════════════════════════════════════════════════════════════

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): LexiDictDatabase =
        Room.databaseBuilder(
            context,
            LexiDictDatabase::class.java,
            LexiDictDatabase.DATABASE_NAME
        )
            .addCallback(LexiDictDatabase.CALLBACK)
            .fallbackToDestructiveMigration()
            .build()

    @Provides fun provideDictionaryDao(db: LexiDictDatabase): DictionaryDao = db.dictionaryDao()
    @Provides fun provideWordIndexDao(db: LexiDictDatabase): WordIndexDao = db.wordIndexDao()
    @Provides fun provideSearchHistoryDao(db: LexiDictDatabase): SearchHistoryDao = db.searchHistoryDao()
    @Provides fun provideFavoritesDao(db: LexiDictDatabase): FavoritesDao = db.favoritesDao()
    @Provides fun provideAudioCacheDao(db: LexiDictDatabase): AudioCacheDao = db.audioCacheDao()
    @Provides fun provideImportJobDao(db: LexiDictDatabase): ImportJobDao = db.importJobDao()
}

// ═══════════════════════════════════════════════════════════════
//  REPOSITORY MODULE
// ═══════════════════════════════════════════════════════════════

@Module
@InstallIn(SingletonComponent::class)
object RepositoryModule {

    @Provides
    @Singleton
    fun provideDictionaryRepository(
        dictionaryDao: DictionaryDao,
        wordIndexDao: WordIndexDao,
        importJobDao: ImportJobDao,
        parserFactory: DictionaryParserFactory
    ): DictionaryRepository = DictionaryRepositoryImpl(
        dictionaryDao, wordIndexDao, importJobDao, parserFactory
    )

    @Provides
    @Singleton
    fun provideSearchRepository(
        wordIndexDao: WordIndexDao,
        searchHistoryDao: SearchHistoryDao,
        dictionaryDao: DictionaryDao,
        searchEngine: SearchEngine
    ): SearchRepository = SearchRepositoryImpl(
        wordIndexDao, searchHistoryDao, dictionaryDao, searchEngine
    )

    @Provides
    @Singleton
    fun provideFavoritesRepository(
        favoritesDao: FavoritesDao
    ): FavoritesRepository = FavoritesRepositoryImpl(favoritesDao)
}

// ═══════════════════════════════════════════════════════════════
//  ENGINE MODULE
// ═══════════════════════════════════════════════════════════════

@Module
@InstallIn(SingletonComponent::class)
object EngineModule {

    @Provides
    @Singleton
    fun provideParserFactory(@ApplicationContext context: Context): DictionaryParserFactory =
        DictionaryParserFactory(context)

    @Provides
    @Singleton
    fun provideSearchEngine(@ApplicationContext context: Context): SearchEngine =
        SearchEngine(context)

    @Provides
    @Singleton
    fun provideAudioEngine(@ApplicationContext context: Context): AudioEngine =
        AudioEngine(context)
}
