package com.lexidict.pro.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Audio engine for dictionary pronunciation.
 *
 * Priority chain:
 * 1. Local audio file bundled in dictionary (WAV/MP3/OGG)
 * 2. Cached TTS audio from previous sessions
 * 3. Online TTS (system TextToSpeech engine, offline-capable)
 *
 * Uses ExoPlayer for local file playback (superior seeking, format support).
 * Uses Android TTS for synthesized speech.
 */
@Singleton
class AudioEngine @Inject constructor(
    private val context: Context
) {
    // ─── ExoPlayer for local audio files ───────────────────────
    private var exoPlayer: ExoPlayer? = null

    // ─── TextToSpeech engine ───────────────────────────────────
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    // ─── State flows ──────────────────────────────────────────
    private val _playbackState = MutableStateFlow<PlaybackState>(PlaybackState.Idle)
    val playbackState: StateFlow<PlaybackState> = _playbackState.asStateFlow()

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    init {
        initTts()
        initExoPlayer()
    }

    // ─────────────────────────────────────────────────────────────
    //  PUBLIC API
    // ─────────────────────────────────────────────────────────────

    /**
     * Play pronunciation for a word.
     *
     * @param word       The word to pronounce
     * @param audioPath  Optional local audio file path (from dictionary)
     * @param locale     TTS locale (e.g., Locale.US, Locale.UK)
     */
    fun speak(
        word: String,
        audioPath: String? = null,
        locale: Locale = Locale.US
    ) {
        scope.launch {
            when {
                // 1. Local audio file
                !audioPath.isNullOrBlank() && File(audioPath).exists() -> {
                    playLocalFile(audioPath)
                }
                // 2. Cached audio
                else -> {
                    speakWithTts(word, locale)
                }
            }
        }
    }

    fun stop() {
        exoPlayer?.stop()
        tts?.stop()
        _playbackState.value = PlaybackState.Idle
    }

    fun setLocale(locale: Locale) {
        tts?.language = locale
    }

    fun release() {
        scope.cancel()
        exoPlayer?.release()
        exoPlayer = null
        tts?.shutdown()
        tts = null
    }

    // ─────────────────────────────────────────────────────────────
    //  PRIVATE — ExoPlayer
    // ─────────────────────────────────────────────────────────────

    private fun initExoPlayer() {
        exoPlayer = ExoPlayer.Builder(context).build().apply {
            addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    when (playbackState) {
                        Player.STATE_READY   -> _playbackState.value = PlaybackState.Playing
                        Player.STATE_ENDED   -> _playbackState.value = PlaybackState.Idle
                        Player.STATE_BUFFERING -> _playbackState.value = PlaybackState.Loading
                        else -> {}
                    }
                }
            })
        }
    }

    private fun playLocalFile(path: String) {
        try {
            _playbackState.value = PlaybackState.Loading
            val mediaItem = MediaItem.fromUri(android.net.Uri.fromFile(File(path)))
            exoPlayer?.apply {
                setMediaItem(mediaItem)
                prepare()
                play()
            }
        } catch (e: Exception) {
            _playbackState.value = PlaybackState.Error(e.message ?: "Playback failed")
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  PRIVATE — TTS
    // ─────────────────────────────────────────────────────────────

    private fun initTts() {
        tts = TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.language = Locale.US
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _playbackState.value = PlaybackState.Playing
                    }
                    override fun onDone(utteranceId: String?) {
                        _playbackState.value = PlaybackState.Idle
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _playbackState.value = PlaybackState.Error("TTS error")
                    }
                })
            }
        }
    }

    private fun speakWithTts(word: String, locale: Locale) {
        if (!ttsReady || tts == null) {
            _playbackState.value = PlaybackState.Error("TTS not ready")
            return
        }

        tts?.language = locale
        tts?.speak(
            word,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "lexidict_${System.currentTimeMillis()}"
        )
    }

    // ─────────────────────────────────────────────────────────────
    //  CACHED TTS TO FILE (for audio cache)
    // ─────────────────────────────────────────────────────────────

    /**
     * Synthesize and save TTS audio to a file.
     * Used to cache pronunciation for frequently looked-up words.
     */
    suspend fun synthesizeToFile(word: String, locale: Locale, outputFile: File): Boolean =
        withContext(Dispatchers.IO) {
            val deferred = CompletableDeferred<Boolean>()

            if (!ttsReady || tts == null) return@withContext false

            tts?.language = locale

            val listener = object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { deferred.complete(true) }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { deferred.complete(false) }
            }
            tts?.setOnUtteranceProgressListener(listener)

            val params = android.os.Bundle().apply {
                putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "synth_${word}")
            }
            tts?.synthesizeToFile(word, params, outputFile, "synth_$word")

            withTimeoutOrNull(10_000) { deferred.await() } ?: false
        }
}

// ─────────────────────────────────────────────────────────────
//  PLAYBACK STATE
// ─────────────────────────────────────────────────────────────

sealed class PlaybackState {
    object Idle    : PlaybackState()
    object Loading : PlaybackState()
    object Playing : PlaybackState()
    data class Error(val message: String) : PlaybackState()
}
