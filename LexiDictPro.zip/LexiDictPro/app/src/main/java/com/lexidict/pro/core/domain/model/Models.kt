package com.lexidict.pro.core.domain.model

import android.net.Uri

// ═══════════════════════════════════════════════════════════════
//  DICTIONARY MODEL
// ═══════════════════════════════════════════════════════════════

/**
 * Represents a dictionary installed in LexiDict Pro.
 * Supports BGL, DSL, StarDict, Dictd, and ZIP formats.
 */
data class Dictionary(
    val id: Long = 0,
    val name: String,
    val author: String = "",
    val description: String = "",
    val sourceLanguage: String = "",
    val targetLanguage: String = "",
    val wordCount: Long = 0,
    val filePath: String,
    val indexPath: String = "",
    val format: DictionaryFormat,
    val sizeBytes: Long = 0,
    val isEnabled: Boolean = true,
    val isIndexed: Boolean = false,
    val importedAt: Long = System.currentTimeMillis(),
    val priority: Int = 0,            // Higher = shown first in results
    val coverImagePath: String? = null,
    val hasPronunciation: Boolean = false,
    val hasImages: Boolean = false
)

/**
 * Supported dictionary file formats.
 */
enum class DictionaryFormat(val extensions: List<String>, val displayName: String) {
    BGL(listOf("bgl"), "Babylon"),
    DSL(listOf("dsl", "lsd"), "ABBYY Lingvo DSL"),
    STARDICT(listOf("ifo", "idx", "dict", "dz"), "StarDict"),
    DICTD(listOf("index", "data"), "Dictd"),
    ZIP(listOf("zip"), "ZIP Archive"),
    UNKNOWN(emptyList(), "Unknown");

    companion object {
        fun fromExtension(ext: String): DictionaryFormat =
            values().firstOrNull { ext.lowercase() in it.extensions } ?: UNKNOWN
    }
}

// ═══════════════════════════════════════════════════════════════
//  SEARCH MODELS
// ═══════════════════════════════════════════════════════════════

/**
 * A single search result entry, combining word + definition
 * from one dictionary source.
 */
data class SearchResult(
    val word: String,
    val definition: String,                 // Raw HTML or plain text
    val definitionHtml: String = definition, // Sanitized HTML for WebView
    val dictionaryId: Long,
    val dictionaryName: String,
    val pronunciation: String? = null,       // IPA or similar
    val audioPath: String? = null,           // Local audio file
    val audioUrl: String? = null,            // Remote TTS URL
    val images: List<String> = emptyList(),  // Base64 or paths
    val synonyms: List<String> = emptyList(),
    val antonyms: List<String> = emptyList(),
    val examples: List<String> = emptyList(),
    val partOfSpeech: String? = null,
    val rank: Float = 0f                     // Search relevance score
)

/**
 * Grouped results: all definitions for one word, across all dictionaries.
 */
data class WordEntry(
    val word: String,
    val results: List<SearchResult>,
    val isFavorite: Boolean = false
)

/**
 * Parameters controlling a search operation.
 */
data class SearchQuery(
    val text: String,
    val mode: SearchMode = SearchMode.PREFIX,
    val maxResults: Int = 50,
    val dictionaryIds: List<Long> = emptyList(), // Empty = all enabled
    val caseSensitive: Boolean = false,
    val includeDefinitions: Boolean = false
)

enum class SearchMode {
    EXACT,          // Exact word match
    PREFIX,         // Starts with (default autocomplete)
    FUZZY,          // Levenshtein distance
    WILDCARD,       // Supports * and ? wildcards
    FULLTEXT,       // Full-text search in definitions
    MORPHOLOGICAL   // Stemmed/lemmatized search
}

// ═══════════════════════════════════════════════════════════════
//  HISTORY & FAVORITES
// ═══════════════════════════════════════════════════════════════

data class SearchHistoryEntry(
    val id: Long = 0,
    val word: String,
    val searchedAt: Long = System.currentTimeMillis(),
    val dictionaryId: Long? = null
)

data class FavoriteEntry(
    val id: Long = 0,
    val word: String,
    val definition: String,
    val dictionaryId: Long,
    val dictionaryName: String,
    val savedAt: Long = System.currentTimeMillis(),
    val note: String = ""
)

// ═══════════════════════════════════════════════════════════════
//  IMPORT MODELS
// ═══════════════════════════════════════════════════════════════

/**
 * Represents an in-progress dictionary import operation.
 */
data class ImportJob(
    val id: String,
    val uri: Uri,
    val fileName: String,
    val format: DictionaryFormat,
    val state: ImportState,
    val progressPercent: Int = 0,
    val errorMessage: String? = null,
    val extractedMetadata: Dictionary? = null
)

enum class ImportState {
    QUEUED,
    DETECTING_FORMAT,
    EXTRACTING_METADATA,
    INDEXING,
    COMPLETED,
    FAILED,
    CANCELLED
}

// ═══════════════════════════════════════════════════════════════
//  SETTINGS MODEL
// ═══════════════════════════════════════════════════════════════

data class AppSettings(
    val theme: AppTheme = AppTheme.SYSTEM,
    val fontSize: FontSize = FontSize.MEDIUM,
    val showPopupOnCopy: Boolean = true,
    val autoPlayPronunciation: Boolean = false,
    val pronunciationLocale: PronunciationLocale = PronunciationLocale.US,
    val searchLanguage: String = "auto",
    val maxHistoryEntries: Int = 500,
    val enableAccessibilityService: Boolean = false,
    val customCss: String = "",
    val enableHapticFeedback: Boolean = true,
    val popupShowDelay: Int = 200,       // ms
    val searchDebounceMs: Int = 150
)

enum class AppTheme { LIGHT, DARK, SYSTEM }
enum class FontSize(val sp: Int) { SMALL(14), MEDIUM(16), LARGE(18), XLARGE(22) }
enum class PronunciationLocale(val tag: String, val displayName: String) {
    US("en-US", "English (US)"),
    UK("en-GB", "English (UK)"),
    AU("en-AU", "English (AU)")
}

// ═══════════════════════════════════════════════════════════════
//  AUDIO MODEL
// ═══════════════════════════════════════════════════════════════

data class AudioEntry(
    val word: String,
    val localPath: String? = null,
    val isPlaying: Boolean = false,
    val durationMs: Long = 0
)
