package com.lexidict.pro.core.data.local.entities

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// ═══════════════════════════════════════════════════════════════
//  DICTIONARY ENTITY
// ═══════════════════════════════════════════════════════════════

@Entity(
    tableName = "dictionaries",
    indices = [Index("format"), Index("is_enabled")]
)
data class DictionaryEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id") val id: Long = 0,

    @ColumnInfo(name = "name") val name: String,
    @ColumnInfo(name = "author") val author: String = "",
    @ColumnInfo(name = "description") val description: String = "",
    @ColumnInfo(name = "source_language") val sourceLanguage: String = "",
    @ColumnInfo(name = "target_language") val targetLanguage: String = "",
    @ColumnInfo(name = "word_count") val wordCount: Long = 0,
    @ColumnInfo(name = "file_path") val filePath: String,
    @ColumnInfo(name = "index_path") val indexPath: String = "",
    @ColumnInfo(name = "format") val format: String,
    @ColumnInfo(name = "size_bytes") val sizeBytes: Long = 0,
    @ColumnInfo(name = "is_enabled") val isEnabled: Boolean = true,
    @ColumnInfo(name = "is_indexed") val isIndexed: Boolean = false,
    @ColumnInfo(name = "imported_at") val importedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "priority") val priority: Int = 0,
    @ColumnInfo(name = "cover_image_path") val coverImagePath: String? = null,
    @ColumnInfo(name = "has_pronunciation") val hasPronunciation: Boolean = false,
    @ColumnInfo(name = "has_images") val hasImages: Boolean = false
)

// ═══════════════════════════════════════════════════════════════
//  WORD INDEX ENTITY — FTS5 virtual table
// ═══════════════════════════════════════════════════════════════

/**
 * FTS5 virtual table for lightning-fast full-text search.
 * Stores word + definition for each dictionary entry.
 *
 * Note: Room's @Fts4/@Fts annotation is used; for FTS5 we use a custom
 * CREATE VIRTUAL TABLE statement in a Migration/Callback.
 */
@Entity(tableName = "word_index_fts")
data class WordIndexFtsEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "rowid") val rowId: Long = 0,

    @ColumnInfo(name = "dictionary_id") val dictionaryId: Long,
    @ColumnInfo(name = "word") val word: String,
    @ColumnInfo(name = "word_lower") val wordLower: String,
    @ColumnInfo(name = "definition") val definition: String,
    @ColumnInfo(name = "pronunciation") val pronunciation: String = "",
    @ColumnInfo(name = "audio_path") val audioPath: String = "",
    @ColumnInfo(name = "sort_key") val sortKey: String = ""  // For alphabetical browsing
)

// ═══════════════════════════════════════════════════════════════
//  SEARCH HISTORY ENTITY
// ═══════════════════════════════════════════════════════════════

@Entity(
    tableName = "search_history",
    indices = [Index("word"), Index("searched_at")]
)
data class SearchHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id") val id: Long = 0,

    @ColumnInfo(name = "word") val word: String,
    @ColumnInfo(name = "searched_at") val searchedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "dictionary_id") val dictionaryId: Long? = null
)

// ═══════════════════════════════════════════════════════════════
//  FAVORITE ENTRY ENTITY
// ═══════════════════════════════════════════════════════════════

@Entity(
    tableName = "favorites",
    indices = [Index("word"), Index("saved_at")],
    foreignKeys = [
        ForeignKey(
            entity = DictionaryEntity::class,
            parentColumns = ["id"],
            childColumns = ["dictionary_id"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class FavoriteEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id") val id: Long = 0,

    @ColumnInfo(name = "word") val word: String,
    @ColumnInfo(name = "definition") val definition: String,
    @ColumnInfo(name = "dictionary_id") val dictionaryId: Long,
    @ColumnInfo(name = "dictionary_name") val dictionaryName: String,
    @ColumnInfo(name = "saved_at") val savedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "note") val note: String = ""
)

// ═══════════════════════════════════════════════════════════════
//  AUDIO CACHE ENTITY
// ═══════════════════════════════════════════════════════════════

@Entity(
    tableName = "audio_cache",
    indices = [Index(value = ["word", "locale"], unique = true)]
)
data class AudioCacheEntity(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id") val id: Long = 0,

    @ColumnInfo(name = "word") val word: String,
    @ColumnInfo(name = "locale") val locale: String,
    @ColumnInfo(name = "local_path") val localPath: String,
    @ColumnInfo(name = "cached_at") val cachedAt: Long = System.currentTimeMillis(),
    @ColumnInfo(name = "duration_ms") val durationMs: Long = 0
)

// ═══════════════════════════════════════════════════════════════
//  IMPORT JOB ENTITY
// ═══════════════════════════════════════════════════════════════

@Entity(tableName = "import_jobs")
data class ImportJobEntity(
    @PrimaryKey
    @ColumnInfo(name = "id") val id: String,

    @ColumnInfo(name = "uri") val uri: String,
    @ColumnInfo(name = "file_name") val fileName: String,
    @ColumnInfo(name = "format") val format: String,
    @ColumnInfo(name = "state") val state: String,
    @ColumnInfo(name = "progress") val progress: Int = 0,
    @ColumnInfo(name = "error_message") val errorMessage: String? = null,
    @ColumnInfo(name = "created_at") val createdAt: Long = System.currentTimeMillis()
)
