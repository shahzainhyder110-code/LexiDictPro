package com.lexidict.pro.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * LexiDictAccessibilityService
 *
 * Captures text selection events system-wide. When the user selects text in
 * any app, the service can read the selected text and dispatch it to the
 * FloatingOverlayService for instant lookup — no copy required.
 *
 * Required permissions in AndroidManifest.xml:
 *   android.permission.BIND_ACCESSIBILITY_SERVICE
 *
 * Service is declared with:
 *   <meta-data android:name="android.accessibilityservice"
 *              android:resource="@xml/accessibility_service_config" />
 */
class LexiDictAccessibilityService : AccessibilityService() {

    companion object {
        const val ACTION_SELECTED_TEXT = "com.lexidict.pro.ACTION_SELECTED_TEXT"
        const val EXTRA_TEXT           = "selected_text"
        private const val MIN_WORD_LEN  = 2
        private const val MAX_WORD_LEN  = 80
        private var isEnabled = false

        /** Called from SettingsScreen / FloatingOverlayService to toggle service awareness. */
        fun setEnabled(enabled: Boolean) {
            isEnabled = enabled
        }
    }

    private var lastDispatchedText = ""

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onServiceConnected() {
        super.onServiceConnected()
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED or
                    AccessibilityEvent.TYPE_VIEW_FOCUSED or
                    AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 100
        }
        serviceInfo = info
    }

    override fun onInterrupt() {
        // No ongoing operations to interrupt
    }

    // ── Event handling ────────────────────────────────────────────────────────

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!isEnabled || event == null) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED -> {
                handleSelectionEvent(event)
            }
            AccessibilityEvent.TYPE_VIEW_FOCUSED -> {
                // Optional: track focused edit text for context
            }
            else -> Unit
        }
    }

    private fun handleSelectionEvent(event: AccessibilityEvent) {
        val source: AccessibilityNodeInfo = event.source ?: return

        try {
            // Extract selected text via selection start/end if available
            val text = source.text?.toString() ?: return
            val start = source.textSelectionStart
            val end   = source.textSelectionEnd

            if (start < 0 || end <= start || end > text.length) return

            val selected = text.substring(start, end).trim()
            if (selected.isBlank()) return

            // Only dispatch single words or short phrases within reasonable bounds
            if (selected.length < MIN_WORD_LEN || selected.length > MAX_WORD_LEN) return

            // Avoid dispatching the same text twice in a row
            if (selected.equals(lastDispatchedText, ignoreCase = true)) return
            lastDispatchedText = selected

            dispatchToOverlay(selected)
        } catch (_: Exception) {
            // AccessibilityNodeInfo can be recycled; swallow errors
        } finally {
            source.recycle()
        }
    }

    /**
     * Dispatch selected text to FloatingOverlayService via broadcast Intent.
     */
    private fun dispatchToOverlay(text: String) {
        val intent = Intent(ACTION_SELECTED_TEXT).apply {
            putExtra(EXTRA_TEXT, text)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }
}
